# DMRfinder
Identifying differentially methylated regions from MethylC-seq data.
For descriptions and usage, please see the UserGuide.

Copyright (C) 2016 John M. Gaspar (jsh58@wildcats.unh.edu), Rutgers University
